--A01 Assignment--

--Home html Page--
Home page contains information like background,future plans, Interest of me

--Online book order html page--
this html is used to order the books online and displays the total cost of the books

--Contact html page--
Here people can contact me.